## module helpers

Supports

 - Shamiko 

   as blacklist / whitelist toggle - (tested at v1.1.1 / 357 on Magisk v28)
    
 - Tricky Store

    as userapps / gms-only toggle - (tested at v1.2.0 / 155 on KernelSU v1.0.2)

  
[Download](https://raw.githubusercontent.com/backslashxx/module_helpers/refs/heads/master/helper_dropper.zip)
